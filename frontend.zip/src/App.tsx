import { Routes, Route } from "react-router";
import AdminLayout from "./components/layouts/admin_layout";
import AddAPlan from "./pages/plans/add-a-plan";

const ADMIN_ROUTES = [
  {
    path: "add-a-plan",
    element: <AddAPlan />,
  },
];

export function App() {
  return (
    <Routes>
      <Route path="/" Component={AdminLayout}>
        {ADMIN_ROUTES.map((route) => (
          <Route path={route.path} element={route.element} />
        ))}
      </Route>
    </Routes>
  );
}

export default App;
