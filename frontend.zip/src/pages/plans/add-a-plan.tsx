import { ComponentExample } from "@/components/component-example";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";


enum APP_FEATURES {
  group
}

const AddAPlan = () => {
  return (
    <div className="flex justify-center items-center min-h-screen w-full ">
      <Card className="w-full max-w-3xl">
        <CardHeader>
          <CardTitle>Plan Informations</CardTitle>
          <CardDescription>
            Please enter plan informations to add a plan
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-4">
            <div className="space-y-2">
              <Label>Plan Name</Label>
              <Input placeholder="e.g Standard plan..." />
            </div>
            <div className="space-y-2">
              <Label>Plan Description</Label>
              <Textarea placeholder="e.g Churn users and ensure users follow group goals..." />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Paystack Plan ID</Label>
                <Input placeholder="Created Paystack Subcription ID..." />
              </div>
              <div className="space-y-2">
                <Label>Stripe Sub ID</Label>
                <Input placeholder="Created Stripe Subcription ID..." />
              </div>
              <div className="space-y-2">
                <Label>Paypal Plan ID</Label>
                <Input placeholder="Created Paypal Subcription ID..." />
              </div>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default AddAPlan;
