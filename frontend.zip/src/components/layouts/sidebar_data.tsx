import { CreditCard } from "lucide-react";

export const SIDEBAR_DATA = [
  {
    sectionName: "Plans & Subscription",
    sectionIcon: CreditCard,
    routes: [
      {
        name: "Create Plan",
        path: "add-a-plan",
      },
      {
        name: "View Plans",
        path: "view-plans",
      },
      {
        name: "View Subcriptions",
        path: "view-subcriptions",
      },
    ],
  },
];
