import { SidebarProvider, SidebarTrigger } from "../ui/sidebar";
import { Outlet } from "react-router-dom";
import AdminSidebar from "./admin_sidebar";

const AdminLayout = () => {
  return (
    <SidebarProvider>
      <AdminSidebar />
      <main className="w-full">
        <div className="sticky top-0">
          <SidebarTrigger />
        </div>
        <Outlet />
      </main>
    </SidebarProvider>
  );
};

export default AdminLayout;
