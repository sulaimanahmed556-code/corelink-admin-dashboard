import { Building2 } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
} from "../ui/sidebar";
import { SIDEBAR_DATA } from "./sidebar_data";
import { Link } from "react-router";

const AdminSidebar = () => {
  return (
    <Sidebar>
      <SidebarHeader>
        <div className="flex gap-2 items-center">
          <div className="p-4 bg-blue-700 text-white rounded-lg">
            <Building2 />
          </div>
          <div className="flex flex-col">
            <h4 className="font-bold text-2xl">CoreLink</h4>
            <p className="text-xs">Admin Dashboard</p>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        {SIDEBAR_DATA.map((section) => (
            
          <SidebarGroup>
            <SidebarGroupLabel className="gap-2">
              <section.sectionIcon />
              {section.sectionName}
            </SidebarGroupLabel>

            <SidebarGroupContent className="pl-4 ml-4 border-l pt-4">
              <SidebarMenu className="gap-2">
                {section.routes.map((route) => (
                  <SidebarMenuItem>
                    <Link to={route.path} className="hover:underline">{route.name}</Link>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>
      <SidebarFooter />
    </Sidebar>
  );
};

export default AdminSidebar;
